rootProject.name = "Readerz-Extended-v2"
include(":app")
