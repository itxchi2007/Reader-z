
EPUB: Implemented via epublib-core. The viewer loads the first spine resource into a WebView. For complete navigation, additional UI (chapter list, next/prev) can be added.

PPTX: Extracts slide text and embedded images. Slides are displayed in a vertical list with text then images. This method shows content offline but may not reproduce complex slide layouts exactly.
